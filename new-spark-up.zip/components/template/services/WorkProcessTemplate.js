import WorkProcess from "../../module/WorkProcess";

const WorkProcessTemplate = ()=>{

    return(

        <>

            <WorkProcess/>

        </>

    )

}


export default WorkProcessTemplate;