import TeamModule from "../../module/TeamModule";

const Team = ()=>{

    return(

        <>

            <TeamModule/>

        </>

    )

}


export default Team;