const TextAboutSpark = ({title , description})=>{

    return(

        <>

            <div className="w-full">

                <div className="w-[90%] m-auto mt-10">

                    <div className="w-full m-auto text-[18px] font-bold">{title}</div>

                    <div className="w-full m-auto mt-6">{description}</div>

                </div>

            </div>

        </>

    )

}


export default TextAboutSpark;