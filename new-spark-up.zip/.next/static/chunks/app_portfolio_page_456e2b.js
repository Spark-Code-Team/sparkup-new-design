(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_portfolio_page_456e2b.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_portfolio_page_456e2b.js",
  "chunks": [
    "static/chunks/node_modules_74bbd6._.js",
    "static/chunks/_e09078._.js",
    "static/chunks/node_modules_swiper_b167c7._.css"
  ],
  "source": "dynamic"
});
