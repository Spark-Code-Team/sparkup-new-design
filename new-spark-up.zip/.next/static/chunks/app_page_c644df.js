(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_c644df.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_c644df.js",
  "chunks": [
    "static/chunks/node_modules_7a67b0._.js",
    "static/chunks/_64e415._.js",
    "static/chunks/node_modules_swiper_b167c7._.css"
  ],
  "source": "dynamic"
});
