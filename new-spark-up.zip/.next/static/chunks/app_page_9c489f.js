(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_9c489f.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_9c489f.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_ea69ac._.js",
    "static/chunks/app_page_a68060.js",
    "static/chunks/app_page_module_24d20b.css"
  ],
  "source": "dynamic"
});
