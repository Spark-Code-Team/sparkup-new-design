(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_61af54.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_61af54.js",
  "chunks": [
    "static/chunks/app_globals_73c377.css",
    "static/chunks/node_modules_next_7ff902._.js",
    "static/chunks/_92e205._.js"
  ],
  "source": "dynamic"
});
