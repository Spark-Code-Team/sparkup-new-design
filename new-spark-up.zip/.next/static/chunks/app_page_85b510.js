(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_85b510.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_85b510.js",
  "chunks": [
    "static/chunks/node_modules_2b5431._.js",
    "static/chunks/_64e415._.js",
    "static/chunks/node_modules_swiper_b167c7._.css"
  ],
  "source": "dynamic"
});
